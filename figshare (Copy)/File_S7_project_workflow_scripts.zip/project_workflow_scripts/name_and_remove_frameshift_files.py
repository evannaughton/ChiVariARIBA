#!/bin/usr/env python3

import os

# Directory containing your genome folders with GFF files
base_dir = '/home/evannaughton/panaroo_test/published_genomes_pangenome/fixed_prokka_gff_files'

# Phrase to search for in GFF files to detect frameshifts
frameshift_keyword = 'frameshift'

# Dictionary to store the count of frameshifted genes for each genome
frameshift_counts = {}

# Walk through all subdirectories and check .gff files for frameshift annotations
for root, dirs, files in os.walk(base_dir):
    for file in files:
        if file.endswith(".gff") or file.endswith(".gff3"):
            file_path = os.path.join(root, file)
            print(f"Checking {file_path} for frameshifts...")
            
            # Initialize the frameshift count for this genome
            frameshift_count = 0
            
            # Open the GFF file and look for the keyword indicating frameshift
            with open(file_path, 'r') as gff_file:
                for line in gff_file:
                    if frameshift_keyword in line:
                        frameshift_count += 1
            
            # If more than 5 frameshifts were found, store the count and remove the file
            if frameshift_count > 5:
                frameshift_counts[file_path] = frameshift_count
                print(f"Found {frameshift_count} frameshifted gene(s) in {file_path}")
                
                # Remove the file with more than 5 frameshift(s)
                os.remove(file_path)
                print(f"Removed {file_path} due to having more than 5 frameshifted genes.")

# Write the frameshift counts to a file (optional)
with open("frameshift_counts.txt", 'w') as output_file:
    for genome, count in frameshift_counts.items():
        output_file.write(f"{genome}: {count} frameshifted gene(s)\n")

# Print the results
if frameshift_counts:
    print("\nFrameshifted genes found and corresponding files removed (more than 5 frameshifts):")
    for genome, count in frameshift_counts.items():
        print(f"{genome}: {count} frameshifted gene(s)")
else:
    print("No frameshifted genes found in any of the GFF files.")


