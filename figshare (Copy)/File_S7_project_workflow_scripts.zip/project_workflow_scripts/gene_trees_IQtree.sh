#!/bin/bash

#SBATCH --job-name=gene_trees        # create a short name for your job
#SBATCH --nodes=1                # Number of nodes for this job
#SBATCH --ntasks=1               # total number of tasks across all nodes
#SBATCH --cpus-per-task=4        # cpu-cores per task (>1 if multi-threaded tasks)
#SBATCH --mem=4G                 # memory to allocate per compute node.
#SBATCH --time=92:00:00          # total run time limit (HH:MM:SS)
#SBATCH --mail-type=ALL          # send email for all events
#SBATCH --mail-user=evan.naughton@universityofgalway.ie

# Set up the Environment and load software
module load Anaconda3/2024.02-1
module load gcc/10.3.1
module load python3

# Your code begins here

conda activate iqtree
conda update iqtree

# Define main directory containing the gene family folders
gene_trees_dir="/data4/enaughton/gene_trees"

# Iterate over each subdirectory in gene_trees_dir
for family_folder in "$gene_trees_dir"/*; do
    if [ -d "$family_folder" ]; then
        # Look for the aligned FASTA file 
        aligned_file=$(find "$family_folder" -name "*_aligned.fasta")

        if [ -f "$aligned_file" ]; then
            iqtree_output="${aligned_file%_aligned.fasta}_iqtree_output"
            # Run IQ-TREE on the aligned file
            iqtree -s "$aligned_file" -m MFP -bb 1000 -nt AUTO -pre "$iqtree_output"

            echo "IQ-TREE analysis completed for ${aligned_file} and saved to ${iqtree_output}"
        else
            echo "No aligned FASTA file found in $family_folder"
        fi
    fi
done
