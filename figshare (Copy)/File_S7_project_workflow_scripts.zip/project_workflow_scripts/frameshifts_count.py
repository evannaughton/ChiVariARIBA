#!/bin/usr/env python3

import os

# Directory containing genome folders 
base_dir = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test'

# Phrase to search for in GFF files to detect frameshifts
frameshift_keyword = 'frameshift'

# Dictionary to store the count of frameshifted genes for each genome
frameshift_counts = {}

# Walk through all subdirectories and check .gff files for frameshift annotations
for root, dirs, files in os.walk(base_dir):
    for file in files:
        if file.endswith(".gff") or file.endswith(".gff3"):
            file_path = os.path.join(root, file)
            print(f"Checking {file_path} for frameshifts...")
            frameshift_count = 0
            with open(file_path, 'r') as gff_file:
                for line in gff_file:
                    if frameshift_keyword in line:
                        frameshift_count += 1
            if frameshift_count > 0:
                frameshift_counts[file_path] = frameshift_count
                print(f"Found {frameshift_count} frameshifted gene(s) in {file_path}")
                # Remove the file with frameshift(s)
                os.remove(file_path)
                print(f"Removed {file_path} due to frameshifted genes.")

# Write the frameshift counts to file 
with open("frameshift_counts.txt", 'w') as output_file:
    for genome, count in frameshift_counts.items():
        output_file.write(f"{genome}: {count} frameshifted gene(s)\n")

# Print results
if frameshift_counts:
    print("\nFrameshifted genes found and corresponding files removed:")
    for genome, count in frameshift_counts.items():
        print(f"{genome}: {count} frameshifted gene(s)")
else:
    print("No frameshifted genes found in any of the GFF files.")

