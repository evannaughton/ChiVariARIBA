import pandas as pd

# Load CSV file
df = pd.read_csv("merged_blast_results.csv", header=None)

# Drop duplicates in column B (index 1) but keep first instance
df = df.drop_duplicates(subset=[1], keep="first")

# Save the updated dataframe
df.to_csv("collapsed_merged_blast_results.csv", index=False, header=False)
