import pandas as pd
import re

# Load BTOP results file into a DataFrame
btop_df = pd.read_csv("blast_results_BTOP.txt", sep="\t", header=None, names=["query_id", "subject_id", "btop"])

# Function to convert BTOP to ARIBA format
def btop_to_ariba(btop_string):
    ariba_variants = []
    position = 1 

    # Use a regex to match numbers (matches) and mismatches/gaps
    elements = re.findall(r'(\d+|[A-Z-]{2})', btop_string)

    for element in elements:
        if element.isdigit():
            position += int(element)
        else:
            # Mismatch or gap
            if element[0] == "-":
                # Gap in reference
                variant = f"{position}{element[1]}-"
            elif element[1] == "-":
                # Gap in query (not directly representable in ARIBA; skip or flag)
                variant = f"{element[0]}{position}-"
            else:
                # Mismatch
                variant = f"{element[0]}{position}{element[1]}"
            ariba_variants.append(variant)
            position += 1  # Increment position for each mismatch/gap

    # Return the ARIBA variant format or "." if no variants
    return " ".join(ariba_variants) if ariba_variants else "."

# Apply the function to BTOP column
btop_df["ariba_variant"] = btop_df["btop"].apply(btop_to_ariba)

# Write output in the original BLAST results format
with open("ariba_compatible_variants.txt", "w") as outfile:
    for _, row in btop_df.iterrows():
        # Format each line as query_id, subject_id, and ariba_variant w/ tab separation
        outfile.write(f"{row['query_id']}\t{row['subject_id']}\t{row['ariba_variant']}\n")



