#!/usr/bin/env python3

import pandas as pd

# Load gene data CSV file
gene_data_file = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/gene_data.csv'
gene_data_df = pd.read_csv(gene_data_file)

# Load BLAST results file
blast_results_file = '/home/evannaughton/BLAST/published_genomes/results2_run/blast_results.txt'
blast_results_df = pd.read_csv(blast_results_file, sep='\t', header=None)

# Assign column names to BLAST results
blast_results_df.columns = ['query', 'subject', 'percent_identity', 'alignment_length', 'mismatches', 'gap_opens',
                            'q_start', 'q_end', 's_start', 's_end', 'evalue', 'bit_score']

# Extract the unique clustering IDs from the BLAST results
blast_clustering_ids = blast_results_df['subject'].unique()

# Filter gene data CSV file to keep only rows that have clustering IDs found in the BLAST results
filtered_gene_data_df = gene_data_df[gene_data_df['clustering_id'].isin(blast_clustering_ids)]

# Output the filtered data to a new CSV file
filtered_gene_data_file = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/filtered_gene_data_published_genes.csv'
filtered_gene_data_df.to_csv(filtered_gene_data_file, index=False)

print(filtered_gene_data_df)

print(f"Filtered data saved to {filtered_gene_data_file}")

