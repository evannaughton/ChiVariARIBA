import pandas as pd

# Load CSV file
df = pd.read_csv("formatted_metadata.csv")

# Define the column order 
column_order = ["clustering_id", "Gene_Label", "Reference_Flag"]

# Reorder columns to include only the specified columns at first
df = df[column_order + [col for col in df.columns if col not in column_order]]

# Add the new 4th column with "." for every row
df.insert(3, "Dot_Column", ".")

# Add new 5th column also with "." for every row
df.insert(4, "Dot_Column2", ".")

# Fill any blank cells with "."
df.fillna(".", inplace=True)

# Concatenate all columns after the 5th column into a single column named "Concatenated_Metadata"
df["Concatenated_Metadata"] = df.iloc[:, 5:].astype(str).apply(lambda row: " |  ".join(row), axis=1)

# Keep only the first five columns and the concatenated column
df = df[["clustering_id", "Gene_Label", "Reference_Flag", "Dot_Column", "Dot_Column2", "Concatenated_Metadata"]]

# Save the final DataFrame to a .tsv file
df.to_csv("ariba_metadata.tsv", sep="\t", index=False)
