import pandas as pd

# Load the merged results file as dataframe
merged_df = pd.read_csv("merged_blast_results.txt", sep="\t", header=None)

# Save dataframe as a CSV file
merged_df.to_csv("merged_blast_results.csv", index=False, header=False)
