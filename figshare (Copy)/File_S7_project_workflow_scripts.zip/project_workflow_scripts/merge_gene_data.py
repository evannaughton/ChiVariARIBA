#!/usr/bin/env python3

import pandas as pd

# Load filtered gene data CSV
filtered_gene_data_file = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/filtered_gene_data_published_genes.csv'
filtered_gene_data_df = pd.read_csv(filtered_gene_data_file)

# Load BLAST results file 
blast_results_file = '/home/evannaughton/BLAST/published_genomes/results2_run/blast_results.txt'
blast_results_df = pd.read_csv(blast_results_file, sep='\t', header=None)

# Assign column names to BLAST results
blast_results_df.columns = ['subject', 'subject_gene', 'percent_identity', 'alignment_length', 'mismatches', 'gap_opens',
                            'q_start', 'q_end', 's_start', 's_end', 'evalue', 'bit_score']

# Merge filtered gene data with the columns from the BLAST results
merged_df = pd.merge(filtered_gene_data_df, blast_results_df[['subject_gene', 'percent_identity', 'alignment_length', 'mismatches', 'gap_opens']], 
                     left_on='clustering_id', right_on='subject_gene', how='left')

# Remove redundant column after merging
merged_df = merged_df.drop(columns=['subject_gene'])

# Save to new CSV file
merged_output_file = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/merged_gene_data_published_genes.csv'
merged_df.to_csv(merged_output_file, index=False)

print(f"Merged data saved to {merged_output_file}")
