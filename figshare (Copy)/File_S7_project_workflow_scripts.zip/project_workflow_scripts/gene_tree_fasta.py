import pandas as pd
import os

# Load CSV file
file_path = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/updated_gene_data_with_family.csv'
gene_data = pd.read_csv(file_path)

# Define directory to save fasta files
output_dir = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/gene_trees/'

# Specify gene families
target_families = ["chiA_1",
"VV2743~~~pgcA1",
"VV2742~~~chbP",
"VV2741~~~exoI",
"VV2740~~~gspK2~~~gspK_1~~~gspK_2",
"VV2739~~~VP2484",
"oppF2~~~VV2738~~~oppF3~~~oppF_1~~~VP2483",
"oppD3~~~VV2737~~~VP2482",
"dppC1~~~VV2736~~~dppC2~~~VP2481~~~dppC_1",
"dppB2~~~VV2735~~~VP2480",
"luxQ3~~~VV2733~~~torS1~~~todS~~~VP2478~~~chiS~~~luxQ_4",
"nagZ~~~VV0700~~~VP0545",
"endoI1~~~endoI_1~~~VP0619",
"group_76231",
"nagA~~~VV1011~~~VP0829",
"nagE~~~VV1012~~~ptsG3~~~ptsG_3~~~VP0831",
"endoI_2",
"group_64662",
"VV2902~~~cod~~~VP2638~~~deaA",
"VV2901~~~VP2637",
"VV2900~~~VP2636~~~gmuC~~~lacE~~~licC~~~licC_1",
"VV2899~~~VP2635",
"VV2898~~~VP2634",
"chbG~~~VV2897~~~VP2633",
"VV2896~~~VP2632",
"nagA~~~nagA_1",
"VV2578~~~VP2338",
"group_61874",
"chb~~~VV0942~~~VP0755",
"cbpD",
"endoI_4~~~endoI_3",
"group_64199",
"group_83650",
"VV0946~~~chiP~~~VP0760",
"VP0854",
"tfoX1~~~VV2306~~~tfoX_1~~~VP1028~~~tfoX1_2~~~sxy_1",
"tfoX_2~~~tfoX2~~~VV1446~~~VP1241",
"appA2~~~VV2734~~~appA1",
"group_75507",
"VPA0055",
"VPA0092",
"VPA0832",
"VVA1099~~~VPA1177",
"VPA1598",
"group_14578",
"ptsG1~~~nagE",
"group_23095",
"group_64816",
"group_84162",
"group_61926",
"chiA3",
"group_50763",
"ybbD",
"gbpA1",
"group_82019",
"group_4269",
"group_51056",
"group_70119",
"group_48536",
"nagC_1~~~VV1010~~~nagC~~~nagC2~~~nagC_2~~~VP0828",
"group_71877",
"group_47085",
"group_3985",
"group_4062",
"nagE~~~ptsG2",
"group_34830",
"group_93671",
"group_93894",
"group_94312",
"group_94393",
"group_94291",
"group_94356",
"group_94292",
"group_94310",
"group_94376",
"group_94296",
"group_94622",
"group_75718",
"group_45478",
"group_48131",
"PLU4760~~~cytR~~~VV3013~~~VP0252"
]

# Loop through each target gene family & filter the genes for the current family
for gene_family in target_families:
    filtered_genes = gene_data[gene_data['gene_family'] == gene_family]
    
    if filtered_genes.empty:
        print(f"No sequences found for gene family: {gene_family}")
        continue
    
    family_dir = os.path.join(output_dir, gene_family)
    os.makedirs(family_dir, exist_ok=True)  
    
    fasta_content = ""
    for _, row in filtered_genes.iterrows():
        header = f">{row['gene_family']}_{row['annotation_id']}_{row['gff_file']}_{row['description']}"
        sequence = row['dna_sequence']
        fasta_content += f"{header}\n{sequence}\n"
    
    # Define a unique fasta file path within the family-specific folder
    fasta_file_path = os.path.join(family_dir, f"{gene_family}_gene_family_sequences.fasta")
    
    # Write to the file & print
    with open(fasta_file_path, 'w') as fasta_file:
        fasta_file.write(fasta_content)
    print(f"FASTA file created for {gene_family} in folder: {family_dir}")


