#!/bin/bash

#SBATCH --job-name=Pchitin        # create a short name for your job
#SBATCH --nodes=1                # Number of nodes for this job
#SBATCH --ntasks=1               # total number of tasks across all nodes
#SBATCH --cpus-per-task=16        # cpu-cores per task (>1 if multi-threaded tasks)
#SBATCH --mem=32G                 # memory to allocate per compute node.
#SBATCH --time=72:00:00          # total run time limit (HH:MM:SS)
#SBATCH --mail-type=ALL          # send email for all events
#SBATCH --mail-user=evan.naughton@universityofgalway.ie

# Set up the Environment and load software
module load Anaconda3
module load gcc/10.3.1
module load python3

# Your code begins here

ulimit -n 51200

input_files="/data4/enaughton/fixed_prokka_gff_files_test/*.gff"

conda activate panaroo_env
conda update panaroo

panaroo -i $input_files -o /data4/enaughton/fixed_prokka_gff_files_test/results2 -t 16 --clean-mode strict --alignment core --aligner mafft --core_threshold 0.95 -f 0.6 --remove-invalid-genes

conda deactivate

/data4/enaughton/bin/iqtree2 -s /data4/enaughton/fixed_prokka_gff_files_test/results2/core_gene_alignment_filtered.aln -m MFP -nt AUTO -B 1000
