#!/bin/bash

# Main directory where all subdirectories are located
main_directory="/home/evannaughton/genomes/gammaproteobacteria/published_genomes/published_genbank_complete/ncbi_dataset/data"

# Loop through each subdirectory in the main directory
for dir in "$main_directory"/*/; do
  fna_file=$(find "$dir" -name "*.fna")
  fna_basename=$(basename "$fna_file" .fna)
  gff_file=$(find "$dir" -name "*.gff")
  if [[ -f "$gff_file" && -f "$fna_file" ]]; then
    # Rename .gff file to match the .fna file
    mv "$gff_file" "$dir/${fna_basename}.gff"
    echo "Renamed $gff_file to ${fna_basename}.gff"
  else
    echo "Either .fna or .gff file not found in $dir"
  fi
done

# Target directory
target_directory="/home/evannaughton/panaroo_test/published_genomes_pangenome"

# Create target directory if it doesnt exist
mkdir -p "$target_directory"

# Find & copy all .gff and .fna files to target directory
find "$main_directory" -type f \( -name "*.gff" -o -name "*.fna" \) -exec cp {} "$target_directory" \;

echo "All .gff and .fna files have been copied to $target_directory"

