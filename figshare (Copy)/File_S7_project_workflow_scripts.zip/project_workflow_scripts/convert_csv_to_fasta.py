#!/bin/usr/env

import pandas as pd

# Load CSV file 
file_path = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results/COLLAPSED_merged_gene_data_published_genes.csv'
gene_data = pd.read_csv(file_path)

# Check the expected columns in your CSV
clustering_id_column = "clustering_id"
nucleotide_seq_column = "dna_sequence"

# Open a new fasta file & Iterate through each row in the CSV file
with open("chitin_database_genes.fasta", "w") as fasta_file
    for index, row in gene_data.iterrows():
        clustering_id = row[clustering_id_column]
        nucleotide_sequence = row[nucleotide_seq_column]

        fasta_file.write(f">{clustering_id}\n")
        fasta_file.write(f"{nucleotide_sequence}\n")

print("FASTA file created: chitin_database_genes.fasta")
