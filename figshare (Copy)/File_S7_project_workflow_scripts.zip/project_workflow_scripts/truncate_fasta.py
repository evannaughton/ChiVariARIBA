def truncate_fasta_headers(input_file, output_file, max_length=49):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            if line.startswith('>'):
                truncated_line = line[:max_length + 1] + '\n'  
                outfile.write(truncated_line)
            else:
                outfile.write(line)

# Specify input & output file names
input_fasta = '/home/evannaughton/genomes/gammaproteobacteria/published_genomes/published_chitin_genes.fasta'
output_fasta = 'truncated_chitin_genes_file.fasta'

truncate_fasta_headers(input_fasta, output_fasta)
