import pandas as pd

# Load CSV files
gene_data_df = pd.read_csv("/home/evannaughton/ARIBA_CHI_ALL_CHI/updated_gene_data_with_family.csv")
blast_results_df = pd.read_csv("collapsed_merged_blast_results.csv")

# Merge on 'clustering_id' with gene_data_df content appearing first in the output
merged_df = pd.merge(gene_data_df, blast_results_df, on="clustering_id", how="outer")

# Replace any blank cells with a full stop "."
merged_df = merged_df.fillna(".")

# Save the merged DataFrame
merged_df.to_csv("final_merged_results.csv", index=False)
