#!/usr/bin/env python3

import pandas as pd
import argparse

# Set up argument parsing to get the input and output file paths
parser = argparse.ArgumentParser(description='Collapse duplicate entries in a CSV by clustering_id')
parser.add_argument('input_file', type=str, help='Path to input CSV file')
parser.add_argument('output_file', type=str, help='Path to output CSV file')

args = parser.parse_args()

# Load CSV file
df = pd.read_csv(args.input_file)

# Group by clustering_id and keep the first occurrence in other columns
collapsed_df = df.groupby('clustering_id').first().reset_index()

# Save the collapsed dataframe back to CSV & print
collapsed_df.to_csv(args.output_file, index=False)
print(f"Data collapsed and saved to {args.output_file}")
