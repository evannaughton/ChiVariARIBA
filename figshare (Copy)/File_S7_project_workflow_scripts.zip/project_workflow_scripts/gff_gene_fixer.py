import os

def process_gff_file(gff_file, output_file):
    gene_entries = set()  
    updated_lines = []    

    with open(gff_file, 'r') as infile:
        for line in infile:
            if line.startswith("#"):
                updated_lines.append(line)  
                continue

            fields = line.strip().split("\t")

            if len(fields) != 9:
                updated_lines.append(line)
                continue

            attributes = fields[8]

            if "ID=gene-" in attributes:
                gene_id = attributes.split("ID=")[1].split(";")[0]
                gene_entries.add(gene_id)

            if fields[2] == "CDS" and "Parent=" in attributes:
                parent_gene = attributes.split("Parent=")[1].split(";")[0]
                if parent_gene not in gene_entries:
                    gene_start = fields[3]
                    gene_end = fields[4]
                    gene_strand = fields[6]
                    gene_score = fields[5]

                    new_gene_entry = [
                        fields[0],   # Chromosome or scaffold ID
                        fields[1],   # Source (e.g., EMBL)
                        "gene",      # Feature type
                        gene_start,  # Start
                        gene_end,    # End
                        gene_score,  # Score
                        gene_strand, # Strand
                        ".",         # Phase
                        f"ID={parent_gene};"
                    ]
                    updated_lines.append("\t".join(new_gene_entry) + "\n")
                    gene_entries.add(parent_gene)  

            # Add the original line to the updated list
            updated_lines.append(line)

    # Write the updated lines to a new output file
    with open(output_file, 'w') as outfile:
        for updated_line in updated_lines:
            outfile.write(updated_line)


def process_gff_directory(gff_directory, output_directory):
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(gff_directory):
        if filename.endswith("prokka.gff"):
            input_file = os.path.join(gff_directory, filename)
            output_file = os.path.join(output_directory, filename)
            print(f"Processing {input_file}...")
            process_gff_file(input_file, output_file)

    print(f"All files processed. Updated files saved in {output_directory}.")


# Input directory & output directory
input_directory = "/home/evannaughton/panaroo_test/published_genomes_pangenome" 
output_directory = "/home/evannaughton/panaroo_test/published_genomes_pangenome/fixed_prokka_gff_files"  

# Run script to process all GFF files in the directory
process_gff_directory(input_directory, output_directory)

