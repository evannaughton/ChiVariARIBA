import pandas as pd

# Load BLAST results file
blast_results_file = 'final_merged_results.csv'
blast_df = pd.read_csv(blast_results_file, sep=',')  

# Confirm the exact column names in case of any whitespaces
print("DataFrame columns:", blast_df.columns)

# Double-check the column name & adjust if necessary
gene_identifier_column = 'clustering_id' 

# Load reference genes list
reference_genes_file = '/home/evannaughton/ARIBA_CHI_REFERENCE_GENES/list_of_reference_genes.txt'
with open(reference_genes_file, 'r') as file:
    reference_genes = set(line.strip() for line in file)

# Add 'Reference_Flag' column: 0 if gene is in reference list, 1 otherwise
blast_df['Reference_Flag'] = blast_df[gene_identifier_column].apply(lambda gene: 0 if gene in reference_genes else 1)

# Add 'Gene_Label' column, marking everything as 1 (indicating they are genes)
blast_df['Gene_Label'] = 1

# Save updated file as CSV & print
output_file = 'formatted_metadata.csv'  
blast_df.to_csv(output_file, sep=',', index=False, header=True) 
print(f"Updated file saved as {output_file}")



