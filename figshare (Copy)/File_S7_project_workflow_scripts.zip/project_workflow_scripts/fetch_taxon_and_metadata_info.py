#!/usr/bin/env python3
from Bio import Entrez
import time
import pandas as pd

 
# Function to locate metadata for each accession within a given list
def fetch_metadata_for_accessions(accession_list):
    batch_size = 10
    metadata_list = []

    for i in range(0, len(accession_list), batch_size):
        batch = accession_list[i:i+batch_size]
        print(f"Processing batch {i//batch_size + 1}: {batch}")

        try:
            search_handle = Entrez.esearch(db="assembly", term=" OR ".join(batch), retmax=batch_size)
            search_results = Entrez.read(search_handle)
            search_handle.close()

            if search_results.get("IdList"):
                summary_handle = Entrez.esummary(db="assembly", id=",".join(search_results["IdList"]))
                summaries = Entrez.read(summary_handle)
                summary_handle.close()

                for summary in summaries["DocumentSummarySet"]["DocumentSummary"]:
                    metadata = {
                        'Accession': summary.get("AssemblyAccession", "Unknown accession"),
                        'Assembly': summary.get("AssemblyName", 'No reporter'),
                        'AssemblyStatus': summary.get("AssemblyStatus", 'No reporter'),
                        'organism': summary.get("Organism", "Unknown organism"),
                        'SpeciesName': summary.get("SpeciesName", "Unknown species"),
                        'Taxid': summary.get("Taxid", "No reporter"),
                        'BioSample': summary.get("BioSampleAccn", 'No reporter'),
                        'BioProject': summary.get("GB_BioProjects", 'No reporter'),
                        'AssemblyReleaseDateGenbank': summary.get("AsmReleaseDate_GenBank", 'No reporter')
                    }
                    
                    metadata_list.append(metadata)

        except Exception as e:
            print(f"Error retrieving data for batch {i//batch_size + 1}: {e}")
        finally:
            time.sleep(1)

    return metadata_list

# Load accession numbers from file
with open("/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/assembly_ids2.txt", "r") as file: 
    accession_list = [line.strip() for line in file.readlines()]

# Fetch metadata for the list of accessions
metadata = fetch_metadata_for_accessions(accession_list)

# Convert metadata to DataFrame and save to CSV
df = pd.DataFrame(metadata)
# Replace 'GCF' with 'GCA' in 'Accession' columns & print
df['Accession'] = df['Accession'].str.replace('GCF', 'GCA')
df.to_csv('/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/metadata_output2.csv', index=False)
print("Metadata file created: metadata_output2.csv")
