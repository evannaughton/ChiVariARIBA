import pandas as pd

# Load BTOP results file & normal BLAST results file
btop_df = pd.read_csv("ariba_compatible_variants.txt", sep="\t", header=None)
normal_blast_df = pd.read_csv("blast_results.txt", sep="\t", header=None)

# Rename only the second column (index 1) in both files to 'sequence_id' for merging
btop_df.rename(columns={1: "sequence_id"}, inplace=True)
normal_blast_df.rename(columns={1: "sequence_id"}, inplace=True)

# Merge based on 'sequence_id'
merged_df = normal_blast_df.merge(btop_df, on="sequence_id", how="left")

# Save the merged result
merged_df.to_csv("merged_blast_results.txt", sep="\t", index=False, header=False)
