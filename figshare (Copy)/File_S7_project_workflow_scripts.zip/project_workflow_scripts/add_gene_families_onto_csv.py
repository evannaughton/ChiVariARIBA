import pandas as pd

# Load updated_gene_data.csv
gene_data_file = "/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/COLLAPSED_merged_gene_data_published_genes.csv"
gene_data = pd.read_csv(gene_data_file)

# Load gene_presence_absence.csv from Panaroo
gene_presence_file = "/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/gene_presence_absence.csv"
gene_presence_absence = pd.read_csv(gene_presence_file)

# Column A in gene_presence_absence.csv is the gene family
gene_family_column = "Gene"

# Find the gene family by searching all columns in gene_presence_absence
def find_gene_family(annotation_id):
    for index, row in gene_presence_absence.iterrows():
        if annotation_id in row.values:
            return row[gene_family_column]
    return None  

# Apply function to map gene families to annotation_ids in updated_gene_data.csv
gene_data['gene_family'] = gene_data['annotation_id'].apply(find_gene_family)

# Save the updated DataFrame to a new CSV file & print
gene_data.to_csv("/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/updated_gene_data_with_family.csv", index=False)
print("Updated CSV with gene family added: updated_gene_data_with_family.csv")
