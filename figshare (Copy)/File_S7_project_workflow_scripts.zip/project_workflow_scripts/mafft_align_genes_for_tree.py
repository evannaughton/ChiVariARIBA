import os
import subprocess

# Define directory containing gene family folders
gene_trees_dir = '/home/evannaughton/panaroo_test/fixed_prokka_gff_files_test/results2/gene_trees/'

# Loop through each folder in the gene_trees directory & Identify the fasta file within the folder
for family_folder in os.listdir(gene_trees_dir):
    family_dir = os.path.join(gene_trees_dir, family_folder)
    
    if os.path.isdir(family_dir):
        fasta_file = None
        for file in os.listdir(family_dir):
            if file.endswith(".fasta"):
                fasta_file = os.path.join(family_dir, file)
                break  
        
        if fasta_file:
            aligned_file = os.path.join(family_dir, f"{family_folder}_aligned.fasta")
            
            # Run MAFFT on the fasta file and output to the aligned file
            mafft_command = ["mafft", "--auto", fasta_file]
            with open(aligned_file, "w") as output_handle:
                subprocess.run(mafft_command, stdout=output_handle)
            
            print(f"Alignment completed for {family_folder} and saved to {aligned_file}")
        else:
            print(f"No FASTA file found in {family_dir}")
