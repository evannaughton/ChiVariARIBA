import requests
import pandas as pd

# Function to fetch linked PubMed articles for a given BioProject ID
def fetch_linked_pubmed_articles(bioproject_id):
    # Construct the elink URL to get PubMed articles linked to this BioProject
    elink_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?dbfrom=bioproject&db=pubmed&id={bioproject_id}&retmode=json"
    
    # Send request
    response = requests.get(elink_url)
    
    # Check for a successful response
    if response.status_code == 200:
        pubmed_data = response.json()
        
        # Extract PubMed IDs from the response
        pubmed_links = pubmed_data.get('linksets', [{}])[0].get('linksetdbs', [{}])[0].get('links', [])
        
        if pubmed_links:
            # Construct PubMed URLs for each linked article
            pubmed_urls = [f"https://pubmed.ncbi.nlm.nih.gov/{pubmed_id}/" for pubmed_id in pubmed_links]
            return "; ".join(pubmed_urls)  
        else:
            return "No linked PubMed articles"
    else:
        return f"Error fetching PubMed articles for BioProject {bioproject_id}"

# Function to process CSV and add a new column with PubMed links
def process_csv_and_add_pubmed_links(file_path, output_path):
    df = pd.read_csv(file_path)
    
    df['PubMedArticles'] = ''
    
    # Iterate through each row and find linked PubMed articles
    for index, row in df.iterrows():
        bioproject_info = row['BioProject']  

        if isinstance(bioproject_info, str) and bioproject_info.startswith("["):
            try:
                bioprojects = eval(bioproject_info)  
            except:
                print(f"Error processing BioProject field at row {index}")
                df.at[index, 'PubMedArticles'] = "Error processing BioProject"
                continue
        else:
            bioprojects = [bioproject_info]

        # Combine results for multiple BioProjects if present
        pubmed_articles = []
        for bioproject in bioprojects:
            bioproject_id = bioproject.get('BioprojectId', 'No reporter') if isinstance(bioproject, dict) else bioproject
            if bioproject_id == 'No reporter' or not bioproject_id:
                pubmed_articles.append("No valid BioProject ID")
            else:
                print(f"Fetching PubMed articles for BioProject {bioproject_id}")
                articles = fetch_linked_pubmed_articles(bioproject_id)
                pubmed_articles.append(articles)
        
        # Join results from multiple BioProjects (if any) into a single string
        df.at[index, 'PubMedArticles'] = " | ".join(pubmed_articles)
    
    # Save updated dataframe back to a new CSV file
    df.to_csv(output_path, index=False)
    print(f"Updated CSV with PubMed links saved to {output_path}")

file_path = "/home/evannaughton/panaroo/all_3_genus/metadata_output.csv"  
output_path = "/home/evannaughton/panaroo/all_3_genus/metadata_output_with_publication.csv"  
process_csv_and_add_pubmed_links(file_path, output_path)



