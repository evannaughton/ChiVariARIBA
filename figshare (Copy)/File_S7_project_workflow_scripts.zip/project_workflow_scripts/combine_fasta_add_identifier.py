import os
import shutil 
from Bio import SeqIO

# Define the base directory where all subdirectories are located
base_dir = "/home/evannaughton/genomes/gammaproteobacteria/chitin_genes_vibrionaceae_subspecies"
output_fasta = "/home/evannaughton/genomes/gammaproteobacteria/chitin_genes_vibrionaceae_subspecies/combined_chitin_genes.fasta"

# Open output FASTA file for writing
with open(output_fasta, 'w') as outfile:
    # Walk through base directory
    for root, dirs, files in os.walk(base_dir):
        # Check if we're in the directory that contains 'gene.fna'
        if "gene.fna" in files:
            grandparent_dir = os.path.basename(os.path.dirname(os.path.dirname(root)))
            gene_fna_path = os.path.join(root, "gene.fna")

            # Read the gene.fna file and add identifier
            with open(gene_fna_path, 'r') as fna_file:
                for record in SeqIO.parse(fna_file, "fasta"):
                    record.id = f"{grandparent_dir}_{record.id}".replace(" ", "_")
                    record.description = record.id 
                    SeqIO.write(record, outfile, "fasta")

print(f"All gene.fna files have been combined into {output_fasta}")






